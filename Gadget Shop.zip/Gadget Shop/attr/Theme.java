package attr;

import java.awt.*;

public class Theme
{
	public static final int GUI_width = 1000;
	public static final int GUI_height = 800;
	public static final int Button_Primary_width = 100;
	
	public static final Color Background_Panel = new Color(255, 255, 255);
	public static final Color Background_Header = new Color(0, 0, 128);
	public static final Color Color_Title = new Color(0, 0, 128);
	public static final Color Color_Button_Primary = new Color(255, 255, 255);
	public static final Color Background_Button_Primary = new Color(0, 0, 128);
	
	public static final Font Font_Title = new Font(Font.SANS_SERIF, Font.BOLD, 40);
	public static final Font Font_Button = new Font(Font.SANS_SERIF, Font.BOLD, 16);
	public static final Font Font_Regular = new Font(Font.SANS_SERIF, Font.PLAIN, 20);
	public static final Font Font_Input = new Font(Font.SANS_SERIF, Font.PLAIN, 18);

}