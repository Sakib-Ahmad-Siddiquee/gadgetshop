package actions;

import java.lang.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import attr.*;

public class ManageProduct extends JFrame implements ActionListener {
	private JPanel panel;
	private ViewProductActions prev;
	private Product product;
	private JButton buttonBack, buttonEdit, buttonDelete, buttonSell, buttonSubmit;
	private JLabel title, header, productIdLabel, productNameLabel, productQtLabel, productPriceLabel, userIdLabel;
	private JTextField productIdA, productNameA, productQtA, productPriceA, userIdA;
	
	public ManageProduct(String pid, ViewProductActions prev) 
	{
		super("Manage Product");
		
		this.setSize(500,400);
		this.setResizable(false);
		this.setLocationRelativeTo(null);
		this.prev = prev;
		
		product = new Product(pid);
		product.fetch();
		
		panel = new JPanel();
		panel.setLayout(null);
		panel.setBackground(Theme.Background_Panel);
		
		productIdLabel = new JLabel("Product ID: "+product.getProductId());
		productIdLabel.setBounds(60, 20, 200, 30);
		productIdLabel.setFont(Theme.Font_Input);
		panel.add(productIdLabel);
		
		productNameLabel = new JLabel("Name: ");
		productNameLabel.setBounds(60, 60, 140, 30);
		productNameLabel.setFont(Theme.Font_Input);
		panel.add(productNameLabel);
		
		productPriceLabel = new JLabel("Price: ");
		productPriceLabel.setBounds(60, 100, 140, 30);
		productPriceLabel.setVisible(false);
		productPriceLabel.setFont(Theme.Font_Input);
		panel.add(productPriceLabel);
		
		userIdLabel = new JLabel("CustomerID: ");
		userIdLabel.setBounds(60, 100, 140, 30);
		userIdLabel.setFont(Theme.Font_Input);
		panel.add(userIdLabel);
		
		productQtLabel = new JLabel("Quantity: ");
		productQtLabel.setBounds(60, 140, 140, 30);
		productQtLabel.setFont(Theme.Font_Input);
		panel.add(productQtLabel);
		
		productNameA = new JTextField(product.getProductName());
		productNameA.setBounds(180, 60, 220, 30);
		productNameA.setEnabled(false);
		productNameA.setFont(Theme.Font_Input);
		panel.add(productNameA);
		
		userIdA = new JTextField("");
		userIdA.setBounds(180, 100, 220, 30);
		userIdA.setFont(Theme.Font_Input);
		panel.add(userIdA);
		
		productPriceA = new JTextField(product.getPrice()+"");
		productPriceA.setBounds(180, 100, 220, 30);
		productPriceA.setFont(Theme.Font_Input);
		productPriceA.setVisible(false);
		panel.add(productPriceA);
		
		productQtA = new JTextField("");
		productQtA.setBounds(180, 140, 220, 30);
		productQtA.setFont(Theme.Font_Input);
		panel.add(productQtA);
		
		buttonEdit = new JButton("Save");
		buttonEdit.setBounds(180, 180, Theme.Button_Primary_width,30);
		buttonEdit.setFont(Theme.Font_Button);
		buttonEdit.setBackground(Theme.Background_Button_Primary);
		buttonEdit.setForeground(Theme.Color_Button_Primary);
		buttonEdit.addActionListener(this);
		panel.add(buttonEdit);
		
		buttonSubmit = new JButton("Submit");
		buttonSubmit.setBounds(180, 180, Theme.Button_Primary_width,30);
		buttonSubmit.setFont(Theme.Font_Button);
		buttonSubmit.setBackground(Theme.Background_Button_Primary);
		buttonSubmit.setForeground(Theme.Color_Button_Primary);
		buttonSubmit.setVisible(false);
		buttonSubmit.addActionListener(this);
		panel.add(buttonSubmit);
		
		buttonDelete = new JButton("Delete");
		buttonDelete.setBounds(300, 180, Theme.Button_Primary_width,30);
		buttonDelete.setFont(Theme.Font_Button);
		buttonDelete.setBackground(Theme.Background_Button_Primary);
		buttonDelete.setForeground(Theme.Color_Button_Primary);
		buttonDelete.addActionListener(this);
		panel.add(buttonDelete);
		
		buttonSell = new JButton("Sell");
		buttonSell.setBounds(60, 180, Theme.Button_Primary_width,30);
		buttonSell.setFont(Theme.Font_Button);
		buttonSell.setBackground(Theme.Background_Button_Primary);
		buttonSell.setForeground(Theme.Color_Button_Primary);
		buttonSell.addActionListener(this);
		panel.add(buttonSell);
		
		this.add(panel);
	}
	
	public void actionPerformed(ActionEvent ae) 
	{
		if (ae.getSource().equals(buttonSell)) 
		{
			try 
			{
				product.sellProduct(userIdA.getText().trim(),Integer.parseInt(productQtA.getText()));
				if (!prev.keywordA.getText().trim().isEmpty())
				{
					prev.table.setModel(Product.searchProduct(prev.keywordA.getText().trim(), prev.byWhatCB.getSelectedItem().toString()));
				}
				else
				{
					prev.table.setModel(Product.searchProduct("", "By Name"));
				}
				this.setVisible(false);
			}
			catch (NumberFormatException e) 
			{
				JOptionPane.showMessageDialog(this,"Invalid Input!"); 
			}
		}
		else if (ae.getSource().equals(buttonEdit)) 
		{
			buttonEdit.setVisible(false);
			buttonSubmit.setVisible(true);
			buttonSell.setEnabled(false);
			productQtA.setText(product.getQuantity()+"");
			productNameA.setEnabled(true);
			userIdLabel.setVisible(false);
			userIdA.setVisible(false);
			productPriceLabel.setVisible(true);
			productPriceA.setVisible(true);
		}
		else if (ae.getSource().equals(buttonSubmit)) 
		{
			try 
			{
				product.updateProduct(productNameA.getText(),Double.parseDouble(productPriceA.getText()),Integer.parseInt(productQtA.getText()));
				if (!prev.keywordA.getText().trim().isEmpty())
				{
					prev.table.setModel(Product.searchProduct(prev.keywordA.getText().trim(), prev.byWhatCB.getSelectedItem().toString()));
				}
				else
				{
					prev.table.setModel(Product.searchProduct("", "By Name"));
				}
				this.setVisible(false);
			}
			catch (NumberFormatException e) {
				JOptionPane.showMessageDialog(this,"Invalid Input!"); 
			}
		}
		else if (ae.getSource().equals(buttonDelete)) 
		{
			product.deleteProduct();
			if (!prev.keywordA.getText().trim().isEmpty())
			{
				prev.table.setModel(Product.searchProduct(prev.keywordA.getText().trim(), prev.byWhatCB.getSelectedItem().toString()));
			}
			else
			{
				prev.table.setModel(Product.searchProduct("", "By Name"));
			}
			this.setVisible(false);
		}
		else {}
	}
}