package actions;

import java.lang.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import attr.*;

public class ManageCustomer extends JFrame implements ActionListener {
	private JPanel panel;
	private ViewCustomerActions prev;
	private Customer customer;
	private JButton buttonBack, buttonEdit, buttonDelete;
	private JLabel title, header, userIdLabel, customerNameLabel, phoneNumberLabel, addressLabel;
	private JTextField userIdA, customerNameA, phoneNumberA, phoneCodeA, addressA;
	
	public ManageCustomer(String cid, ViewCustomerActions prev) 
	{
		super("Manage Customer");
		
		this.setSize(500,400);
		this.setResizable(false);
		this.setLocationRelativeTo(null);
		this.prev = prev;
		
		customer = new Customer(cid);
		customer.fetch();
		
		panel = new JPanel();
		panel.setLayout(null);
		panel.setBackground(Theme.Background_Panel);
		
		userIdLabel = new JLabel("Customer ID: "+customer.getUserId());
		userIdLabel.setBounds(60, 20, 200, 30);
		userIdLabel.setFont(Theme.Font_Input);
		panel.add(userIdLabel);
		
		customerNameLabel = new JLabel("Name: ");
		customerNameLabel.setBounds(60, 60, 140, 30);
		customerNameLabel.setFont(Theme.Font_Input);
		panel.add(customerNameLabel);
		
		phoneNumberLabel = new JLabel("Phone: ");
		phoneNumberLabel.setBounds(60, 100, 140, 30);
		phoneNumberLabel.setFont(Theme.Font_Input);
		panel.add(phoneNumberLabel);
		
		addressLabel = new JLabel("Address: ");
		addressLabel.setBounds(60, 140, 140, 30);
		addressLabel.setFont(Theme.Font_Input);
		panel.add(addressLabel);
		
		customerNameA = new JTextField(customer.getCustomerName());
		customerNameA.setBounds(160, 60, 220, 30);
		customerNameA.setFont(Theme.Font_Input);
		panel.add(customerNameA);
		
		phoneCodeA = new JTextField("+880");
		phoneCodeA.setEnabled(false);
		phoneCodeA.setBounds(160, 100, 50, 30);
		phoneCodeA.setFont(Theme.Font_Input);
		panel.add(phoneCodeA);
		

		phoneNumberA = new JTextField(customer.getPhoneNumber().substring(4)+"");
		phoneNumberA.setBounds(205, 100, 180, 30);
		phoneNumberA.setFont(Theme.Font_Input);
		panel.add(phoneNumberA);
		
		addressA = new JTextField(customer.getAddress()+"");
		addressA.setBounds(160, 140, 220, 30);
		addressA.setFont(Theme.Font_Input);
		panel.add(addressA);
		
		buttonEdit = new JButton("Save");
		buttonEdit.setBounds(60, 180, Theme.Button_Primary_width, 30);
		buttonEdit.setFont(Theme.Font_Button);
		buttonEdit.setBackground(Theme.Background_Button_Primary);
		buttonEdit.setForeground(Theme.Color_Button_Primary);
		buttonEdit.addActionListener(this);
		panel.add(buttonEdit);
		
		buttonDelete = new JButton("Delete");
		buttonDelete.setBounds(180, 180, Theme.Button_Primary_width,30);
		buttonDelete.setFont(Theme.Font_Button);
		buttonDelete.setBackground(Theme.Background_Button_Primary);
		buttonDelete.setForeground(Theme.Color_Button_Primary);
		buttonDelete.addActionListener(this);
		panel.add(buttonDelete);
		
		this.add(panel);
	}
	
	public void actionPerformed(ActionEvent ae) 
	{
		if (ae.getSource().equals(buttonEdit)) 
		{
			try 
			{
				customer.updateCustomer(customerNameA.getText(), Integer.parseInt(phoneNumberA.getText()), addressA.getText().trim());
				if (!prev.keywordA.getText().trim().isEmpty())
				{
					prev.table.setModel(Customer.searchCustomer(prev.keywordA.getText().trim(), prev.byWhatCB.getSelectedItem().toString()));
				}
				else
				{
					prev.table.setModel(Customer.searchCustomer("", "By Name"));
				}
				this.setVisible(false);
			}
			catch (NumberFormatException e) 
			{
				JOptionPane.showMessageDialog(this,"Invalid Input!"); 
			}
		}
		else if (ae.getSource().equals(buttonDelete)) 
		{
			customer.deleteCustomer();
			if (!prev.keywordA.getText().trim().isEmpty())
			{
				prev.table.setModel(Customer.searchCustomer(prev.keywordA.getText().trim(), prev.byWhatCB.getSelectedItem().toString()));
			}
			else
			{
				prev.table.setModel(Customer.searchCustomer("", "By Name"));
			}
			this.setVisible(false);
		}
		else {}
	}
}