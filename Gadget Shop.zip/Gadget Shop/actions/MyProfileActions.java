package actions;

import java.lang.*;
import javax.swing.*;
import java.awt.*;
import javax.swing.border.*;
import java.awt.event.*;
import attr.*;

public class MyProfileActions extends JFrame implements ActionListener {
	private JPanel panel;
	private JButton buttonEdit, buttonBack, buttonLogout, buttonSubmit, buttonPass, buttonDelete;
	private JFrame backActions;
	private User usr;
	private Employee employee;
	private Customer customer;
	private JLabel title, header, usernameLabel, nameLabel, phoneLabel, addressLabel;
	private JTextField nameA, phoneA1, phoneA2, addressA;
	private JLabel roleLabel, salaryLabel;
	
	public MyProfileActions(JFrame actions, Customer customer) 
	{
		super("My Profile");
		
		this.setSize(Theme.GUI_width, Theme.GUI_height);
		this.setResizable(false);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setLocationRelativeTo(null);
		
		panel = new JPanel();
		panel.setLayout(null);
		panel.setBackground(Theme.Background_Panel);
		
		backActions = actions;
		this.customer = customer;
		this.usr = (User) customer;
		
		title = new JLabel("My Profile");
		title.setBounds(370, 40, 260,75);
		title.setOpaque(true);
		title.setBorder(new EmptyBorder(0,20,0,0));
		title.setFont(Theme.Font_Title);
		title.setForeground(Theme.Color_Title);
		panel.add(title);
		
		buttonEdit = new JButton("Edit Profile");
		buttonEdit.setBounds(60, 340, 120, 30);
		buttonEdit.setFont(Theme.Font_Button);
		buttonEdit.setBackground(Theme.Background_Button_Primary);
		buttonEdit.setForeground(Theme.Color_Button_Primary);
		buttonEdit.addActionListener(this);
		panel.add(buttonEdit);
		
		buttonSubmit = new JButton("Submit");
		buttonSubmit.setBounds(60, 340, 120, 30);
		buttonSubmit.setFont(Theme.Font_Button);
		buttonSubmit.setBackground(Theme.Background_Button_Primary);
		buttonSubmit.setForeground(Theme.Color_Button_Primary);
		buttonSubmit.setVisible(false);
		buttonSubmit.addActionListener(this);
		panel.add(buttonSubmit);
		
		buttonPass = new JButton("Change Password");
		buttonPass.setBounds(Theme.GUI_width-220, 220, 200, 30);
		buttonPass.setFont(Theme.Font_Button);
		buttonPass.setBackground(Theme.Background_Button_Primary);
		buttonPass.setForeground(Theme.Color_Button_Primary);
		buttonPass.addActionListener(this);
		panel.add(buttonPass);
		
		buttonDelete = new JButton("Delete Account");
		buttonDelete.setBounds(Theme.GUI_width-220, 260, 200, 30);
		buttonDelete.setFont(Theme.Font_Button);
		buttonDelete.setBackground(Theme.Background_Button_Primary);
		buttonDelete.setForeground(Theme.Color_Button_Primary);
		buttonDelete.addActionListener(this);
		panel.add(buttonDelete);
		
		buttonLogout = new JButton("Logout");
		buttonLogout.setBounds(Theme.GUI_width-220, 140, 200, 30);
		buttonLogout.setFont(Theme.Font_Button);
		buttonLogout.setBackground(Color.WHITE);
		buttonLogout.setForeground(Theme.Color_Title);
		buttonLogout.addActionListener(this);
		panel.add(buttonLogout);
		
		buttonBack = new JButton("Back");
		buttonBack.setBounds(Theme.GUI_width-220, 180, 200, 30);
		buttonBack.setFont(Theme.Font_Button);
		buttonBack.setBackground(Theme.Background_Button_Primary);
		buttonBack.setForeground(Theme.Color_Button_Primary);
		buttonBack.addActionListener(this);
		panel.add(buttonBack);
		
		usernameLabel = new JLabel("User ID:         "+customer.getUserId());
		usernameLabel.setBounds(60, 140, 440, 30);
		usernameLabel.setFont(Theme.Font_Regular);
		panel.add(usernameLabel);
		
		nameLabel = new JLabel("Name: ");
		nameLabel.setBounds(60, 190, 440, 30);
		nameLabel.setFont(Theme.Font_Regular);
		panel.add(nameLabel);
		
		phoneLabel = new JLabel("Phone No: ");
		phoneLabel.setBounds(60, 240, 440, 30);
		phoneLabel.setFont(Theme.Font_Regular);
		panel.add(phoneLabel);
		
		nameA = new JTextField(customer.getCustomerName());
		nameA.setBounds(180, 190, 220, 30);
		nameA.setFont(Theme.Font_Input);
		nameA.setEnabled(false);
		nameA.setDisabledTextColor(Color.BLACK);
		panel.add(nameA);
		
		phoneA1 = new JTextField("+880");
		phoneA1.setBounds(180, 240, 50, 30);
		phoneA1.setFont(Theme.Font_Input);
		phoneA1.setEnabled(false);
		phoneA1.setDisabledTextColor(Color.BLACK);
		panel.add(phoneA1);
		
		phoneA2 = new JTextField(customer.getPhoneNumber().substring(4));
		phoneA2.setBounds(225, 240, 180, 30);
		phoneA2.setFont(Theme.Font_Input);
		phoneA2.setEnabled(false);
		phoneA2.setDisabledTextColor(Color.BLACK);
		panel.add(phoneA2);
		
		addressA = new JTextField(customer.getAddress());
		addressA.setBounds(180, 290, 220, 30);
		addressA.setEnabled(false);
		addressA.setFont(Theme.Font_Input);
		addressA.setDisabledTextColor(Color.BLACK);
		panel.add(addressA);
		
		addressLabel = new JLabel("Address: ");
		addressLabel.setBounds(60, 290, 440, 30);
		addressLabel.setFont(Theme.Font_Regular);
		panel.add(addressLabel);
		
		header = new JLabel();
		header.setBackground(Theme.Background_Header);
		header.setOpaque(true);
		header.setBounds(0, 0, Theme.GUI_width, 75);
		panel.add(header);
		
		this.add(panel);
	}
	
	public MyProfileActions(JFrame actions, Employee employee) 
	{
		super("My Profile");
		
		this.setSize(Theme.GUI_width, Theme.GUI_height);
		this.setResizable(false);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setLocationRelativeTo(null);
		
		panel = new JPanel();
		panel.setLayout(null);
		panel.setBackground(Theme.Background_Panel);
		
		backActions = actions;
		this.employee = employee;
		this.usr = (User) employee;
		
		title = new JLabel("My Profile");
		title.setBounds(370, 40, 260,75);
		title.setOpaque(true);
		title.setBorder(new EmptyBorder(0,20,0,0));
		title.setFont(Theme.Font_Title);
		title.setForeground(Theme.Color_Title);
		panel.add(title);
		
		buttonEdit = new JButton("Edit Profile");
		buttonEdit.setBounds(60, 380, 120, 30);
		buttonEdit.setFont(Theme.Font_Button);
		buttonEdit.setBackground(Theme.Background_Button_Primary);
		buttonEdit.setForeground(Theme.Color_Button_Primary);
		buttonEdit.addActionListener(this);
		panel.add(buttonEdit);
		
		buttonSubmit = new JButton("Submit");
		buttonSubmit.setBounds(60, 380, 120, 30);
		buttonSubmit.setFont(Theme.Font_Button);
		buttonSubmit.setBackground(Theme.Background_Button_Primary);
		buttonSubmit.setForeground(Theme.Color_Button_Primary);
		buttonSubmit.setVisible(false);
		buttonSubmit.addActionListener(this);
		panel.add(buttonSubmit);
		
		buttonPass = new JButton("Change Password");
		buttonPass.setBounds(Theme.GUI_width-220, 220, 200, 30);
		buttonPass.setFont(Theme.Font_Button);
		buttonPass.setBackground(Theme.Background_Button_Primary);
		buttonPass.setForeground(Theme.Color_Button_Primary);
		buttonPass.addActionListener(this);
		panel.add(buttonPass);
		
		buttonLogout = new JButton("Logout");
		buttonLogout.setBounds(Theme.GUI_width-220, 140, 200, 30);
		buttonLogout.setFont(Theme.Font_Button);
		buttonLogout.setBackground(Color.WHITE);
		buttonLogout.setForeground(Theme.Color_Title);
		buttonLogout.addActionListener(this);
		panel.add(buttonLogout);
		
		buttonBack = new JButton("Back");
		buttonBack.setBounds(Theme.GUI_width-220, 180, 200, 30);
		buttonBack.setFont(Theme.Font_Button);
		buttonBack.setBackground(Theme.Background_Button_Primary);
		buttonBack.setForeground(Theme.Color_Button_Primary);
		buttonBack.addActionListener(this);
		panel.add(buttonBack);
		
		usernameLabel = new JLabel("User ID:        "+employee.getUserId());
		usernameLabel.setBounds(60, 140, 440, 30);
		usernameLabel.setFont(Theme.Font_Regular);
		panel.add(usernameLabel);
		
		nameLabel = new JLabel("Name: ");
		nameLabel.setBounds(60, 190, 440, 30);
		nameLabel.setFont(Theme.Font_Regular);
		panel.add(nameLabel);
		
		phoneLabel = new JLabel("Phone No: ");
		phoneLabel.setBounds(60, 240, 440, 30);
		phoneLabel.setFont(Theme.Font_Regular);
		panel.add(phoneLabel);
		
		roleLabel = new JLabel("Role:             "+employee.getRole());
		roleLabel.setBounds(60, 290, 440, 30);
		roleLabel.setFont(Theme.Font_Regular);
		panel.add(roleLabel);
		
		salaryLabel = new JLabel("Salary:          "+employee.getSalary());
		salaryLabel.setBounds(60, 340, 440, 30);
		salaryLabel.setFont(Theme.Font_Regular);
		panel.add(salaryLabel);
		
		
		nameA = new JTextField(employee.getEmployeeName());
		nameA.setBounds(180, 190, 220, 30);
		nameA.setFont(Theme.Font_Input);
		nameA.setEnabled(false);
		nameA.setDisabledTextColor(Color.BLACK);
		panel.add(nameA);
		
		phoneA1 = new JTextField("+880");
		phoneA1.setBounds(180, 240, 50, 30);
		phoneA1.setFont(Theme.Font_Input);
		phoneA1.setEnabled(false);
		phoneA1.setDisabledTextColor(Color.BLACK);
		panel.add(phoneA1);
		
		phoneA2 = new JTextField(employee.getPhoneNumber().substring(4));
		phoneA2.setBounds(225, 240, 180, 30);
		phoneA2.setFont(Theme.Font_Input);
		phoneA2.setEnabled(false);
		phoneA2.setDisabledTextColor(Color.BLACK);
		panel.add(phoneA2);
		
		header = new JLabel();
		header.setBackground(Theme.Background_Header);
		header.setOpaque(true);
		header.setBounds(0, 0, Theme.GUI_width, 75);
		panel.add(header);
		
		this.add(panel);
	}
	
	public void actionPerformed(ActionEvent ae) 
	{
		if (ae.getSource().equals(buttonBack)) 
		{
			this.setVisible(false);
			backActions.setVisible(true);
		}
		else if (ae.getSource().equals(buttonLogout)) 
		{
			this.setVisible(false);
			new LoginActions().setVisible(true);
		}
		else if (ae.getSource().equals(buttonEdit)) 
		{
			buttonEdit.setVisible(false);
			buttonSubmit.setVisible(true);
			nameA.setEnabled(true);
			phoneA2.setEnabled(true);
			if (customer!=null)
			{
				addressA.setEnabled(true);
			}
		}
		else if (ae.getSource().equals(buttonSubmit)) 
		{
			
			if (customer!=null) 
			{
				addressA.setEnabled(false);
				try 
				{
					customer.updateCustomer(nameA.getText().trim(), Integer.parseInt(phoneA2.getText()), addressA.getText().trim());
					buttonEdit.setVisible(true);
					buttonSubmit.setVisible(false);
					nameA.setEnabled(false);
					phoneA2.setEnabled(false);
				}
				catch (NumberFormatException e) 
				{
					JOptionPane.showMessageDialog(null,"Invalid Number!");
				}
			}
			else if (employee!=null) 
			{
				try 
				{
					employee.updateEmployee(nameA.getText().trim(), Integer.parseInt(phoneA2.getText()), employee.getRole(), employee.getSalary());
					buttonEdit.setVisible(true);
					buttonSubmit.setVisible(false);
					nameA.setEnabled(false);
					phoneA2.setEnabled(false);
				}
				catch (NumberFormatException e) 
				{
					JOptionPane.showMessageDialog(null,"Invalid number!");
				}
			}
		}
		else if (ae.getSource().equals(buttonPass)) 
		{
			new ChangePasswordActions(this.usr).setVisible(true);
		}
		else if (ae.getSource().equals(buttonDelete)) 
		{
			int input = JOptionPane.showConfirmDialog(null, "Sure to Delete?", "Delete"+customer.getUserId()+"?", JOptionPane.YES_NO_OPTION);
			if (input == 0) 
			{
				customer.deleteCustomer();
				this.setVisible(false);
				new LoginActions().setVisible(true);
			}
			else {}
		}
		else {}
	}
}