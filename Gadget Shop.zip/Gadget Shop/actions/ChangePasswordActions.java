package actions;

import java.lang.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import attr.*;

public class ChangePasswordActions extends JFrame implements ActionListener {
	private User user;
	private JPanel panel;
	private JLabel oldLabel, newLabel;
	private JPasswordField oldPF, newPF;
	private JButton buttonSubmit, buttonCancel;
	
	public ChangePasswordActions(User user) {
		super("Change Password");
		
		this.setSize(500,200);
		this.setResizable(false);
		this.setLocationRelativeTo(null);
		
		this.user = user;
		
		panel = new JPanel();
		panel.setLayout(null);
		
		oldLabel = new JLabel("Old Password: ");
		oldLabel.setBounds(40, 20, 150, 30);
		oldLabel.setFont(Theme.Font_Input);
		panel.add(oldLabel);
		
		oldPF = new JPasswordField();
		oldPF.setBounds(160, 20, 280, 30);
		oldPF.setFont(Theme.Font_Input);
		panel.add(oldPF);
		
		newLabel = new JLabel("New Password: ");
		newLabel.setBounds(40, 70, 150, 30);
		newLabel.setFont(Theme.Font_Input);
		panel.add(newLabel);
		
		newPF = new JPasswordField();
		newPF.setBounds(160, 70, 280, 30);
		newPF.setFont(Theme.Font_Input);
		panel.add(newPF);
		
		buttonSubmit = new JButton("Change");
		buttonSubmit.setBounds(90, 120, Theme.Button_Primary_width, 30);
		buttonSubmit.setFont(Theme.Font_Button);
		buttonSubmit.setBackground(Theme.Background_Button_Primary);
		buttonSubmit.setForeground(Theme.Color_Button_Primary);
		buttonSubmit.addActionListener(this);
		panel.add(buttonSubmit);
		
		buttonCancel = new JButton("Cancel");
		buttonCancel.setBounds(300, 120, Theme.Button_Primary_width,30);
		buttonCancel.setFont(Theme.Font_Button);
		buttonCancel.setBackground(Theme.Background_Button_Primary);
		buttonCancel.setForeground(Theme.Color_Button_Primary);
		buttonCancel.addActionListener(this);
		panel.add(buttonCancel);
		
		this.add(panel);
	}
	
	public void actionPerformed(ActionEvent ae) 
	{
		if (ae.getSource().equals(buttonSubmit)) 
		{
			user.changePassword(this, oldPF.getText(), newPF.getText());
		}
		else if (ae.getSource().equals(buttonCancel)) 
		{
			this.setVisible(false);
		}
		else {}
	}
}