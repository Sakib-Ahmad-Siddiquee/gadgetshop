package actions;

import java.lang.*;
import javax.swing.*;
import java.awt.*;
import javax.swing.table.*;
import javax.swing.border.*;
import java.awt.event.*;
import attr.*;

public class ViewCustomerActions extends JFrame implements ActionListener {
	private JPanel panel;
	private JFrame actions;
	private Employee employee;
	private JScrollPane frame;
	JComboBox byWhatCB;
	JTable table;
	private JButton buttonLogout, buttonBack, buttonCheck;
	private JLabel title, header, keywordLabel;
	JTextField keywordA;
	
	public ViewCustomerActions(JFrame prev, Employee employee) 
	{
		super("View Customer");
		
		this.setSize(Theme.GUI_width, Theme.GUI_height);
		this.setResizable(false);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setLocationRelativeTo(null);
		this.actions = prev;
		
		panel = new JPanel();
		panel.setLayout(null);
		panel.setBackground(Theme.Background_Panel);
		
		title = new JLabel("View Customer");
		title.setBounds(330, 40, 340,75);
		title.setOpaque(true);
		title.setBorder(new EmptyBorder(0,20,0,0));
		title.setFont(Theme.Font_Title);
		title.setForeground(Theme.Color_Title);
		panel.add(title);
		
		buttonLogout = new JButton("Logout");
		buttonLogout.setBounds(Theme.GUI_width-140, 140, Theme.Button_Primary_width, 30);
		buttonLogout.setFont(Theme.Font_Button);
		buttonLogout.setBackground(Color.WHITE);
		buttonLogout.setForeground(Theme.Color_Title);
		buttonLogout.addActionListener(this);
		panel.add(buttonLogout);
		
		buttonBack = new JButton("Back");
		buttonBack.setBounds(Theme.GUI_width-140, 180, Theme.Button_Primary_width,30);
		buttonBack.setFont(Theme.Font_Button);
		buttonBack.setBackground(Theme.Background_Button_Primary);
		buttonBack.setForeground(Theme.Color_Button_Primary);
		buttonBack.addActionListener(this);
		panel.add(buttonBack);
		
		keywordLabel = new JLabel("Keyword: ");
		keywordLabel.setBounds(60, 140, 140, 30);
		keywordLabel.setFont(Theme.Font_Regular);
		panel.add(keywordLabel);
		
		keywordA = new JTextField();
		keywordA.setBounds(160, 140, 240, 30);
		keywordA.setFont(Theme.Font_Input);
		panel.add(keywordA);
		
		byWhatCB = new JComboBox(new Object[]{"By ID", "By Name"});
		byWhatCB.setBounds(400, 140, 100,30);
		byWhatCB.setFont(Theme.Font_Input);
		panel.add(byWhatCB);
		
		buttonCheck = new JButton("Search");
		buttonCheck.setBounds(500, 140, Theme.Button_Primary_width,30);
		buttonCheck.setFont(Theme.Font_Button);
		buttonCheck.setBackground(Theme.Background_Button_Primary);
		buttonCheck.setForeground(Theme.Color_Button_Primary);
		buttonCheck.addActionListener(this);
		panel.add(buttonCheck);
		
		table = new JTable();
		DefaultTableModel model = new DefaultTableModel();
		model.setColumnIdentifiers(Customer.columnName);
		table.setModel(model);
		table.addMouseListener(new MouseAdapter() 
		{
			public void mouseClicked(MouseEvent evt) 
			{
               jTable_ClickMouseClicked(evt);
            }
		});
		frame = new JScrollPane(table);
		frame.setBounds(40,185,600,300);
		panel.add(frame);
		
		table.setModel(Customer.searchCustomer("", "By Name"));
		
		header = new JLabel();
		header.setBackground(Theme.Background_Header);
		header.setOpaque(true);
		header.setBounds(0, 0, Theme.GUI_width, 75);
		panel.add(header);
		
		this.add(panel);
	}

	public void actionPerformed(ActionEvent ae) 
	{
		if (ae.getSource().equals(buttonLogout)) 
		{
			this.setVisible(false);
			new LoginActions().setVisible(true);
		}
		else if (ae.getSource().equals(buttonBack)) 
		{
			this.setVisible(false);
			actions.setVisible(true);
		}
		else if (ae.getSource().equals(buttonCheck)) 
		{
			table.setModel(Customer.searchCustomer(keywordA.getText().trim(), byWhatCB.getSelectedItem().toString()));
		}
		else {}
	}
	
	private void jTable_ClickMouseClicked(MouseEvent evt) 
	{		
       int index = table.getSelectedRow();

       TableModel model = table.getModel();

       String value1 = model.getValueAt(index, 0).toString();
	   new ManageCustomer(value1, this).setVisible(true);
    }
}