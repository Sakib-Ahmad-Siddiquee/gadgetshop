package actions;

import java.lang.*;
import javax.swing.*;
import java.awt.*;
import javax.swing.border.*;
import java.awt.event.*;
import attr.*;

public class AddProductActions extends JFrame implements ActionListener {
	private JPanel panel;
	private ViewProductActions actions;
	private Employee employee;
	private JButton buttonLogout, buttonBack, buttonAdd;
	private JLabel title, header, productNameLabel, productQtLabel, productPriceLabel;
	private JTextField productNameA, productQtA, productPriceA;
	
	public AddProductActions(ViewProductActions prev, Employee employee) {
		super("Add Product");
		
		this.setSize(Theme.GUI_width, Theme.GUI_height);
		this.setResizable(false);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setLocationRelativeTo(null);
		this.actions = prev;
		this.employee = employee;
		
		panel = new JPanel();
		panel.setLayout(null);
		panel.setBackground(Theme.Background_Panel);
		
		title = new JLabel("Add Product");
		title.setBounds(360, 40, 280,75);
		title.setOpaque(true);
		title.setBorder(new EmptyBorder(0,20,0,0));
		title.setFont(Theme.Font_Title);
		title.setForeground(Theme.Color_Title);
		panel.add(title);
		
		buttonLogout = new JButton("Logout");
		buttonLogout.setBounds(Theme.GUI_width-140, 190, Theme.Button_Primary_width,30);
		buttonLogout.setFont(Theme.Font_Button);
		buttonLogout.setBackground(Color.WHITE);
		buttonLogout.setForeground(Theme.Color_Title);
		buttonLogout.addActionListener(this);
		panel.add(buttonLogout);
		
		buttonBack = new JButton("Back");
		buttonBack.setBounds(Theme.GUI_width-140, 240, Theme.Button_Primary_width,30);
		buttonBack.setFont(Theme.Font_Button);
		buttonBack.setBackground(Theme.Background_Button_Primary);
		buttonBack.setForeground(Theme.Color_Button_Primary);
		buttonBack.addActionListener(this);
		panel.add(buttonBack);
		
		productNameLabel = new JLabel("Name: ");
		productNameLabel.setBounds(60, 190, 140, 30);
		productNameLabel.setFont(Theme.Font_Regular);
		panel.add(productNameLabel);
		
		productPriceLabel = new JLabel("Price: ");
		productPriceLabel.setBounds(60, 240, 140, 30);
		productPriceLabel.setFont(Theme.Font_Regular);
		panel.add(productPriceLabel);
		
		productQtLabel = new JLabel("Quantity: ");
		productQtLabel.setBounds(60, 290, 140, 30);
		productQtLabel.setFont(Theme.Font_Regular);
		panel.add(productQtLabel);
		
		productNameA = new JTextField();
		productNameA.setBounds(180, 190, 220, 30);
		productNameA.setFont(Theme.Font_Input);
		panel.add(productNameA);
		
		productPriceA = new JTextField();
		productPriceA.setBounds(180, 240, 220, 30);
		productPriceA.setFont(Theme.Font_Input);
		panel.add(productPriceA);
		
		productQtA = new JTextField();
		productQtA.setBounds(180, 290, 220, 30);
		productQtA.setFont(Theme.Font_Input);
		panel.add(productQtA);
		
		buttonAdd = new JButton("Add");
		buttonAdd.setBounds(180, 340, Theme.Button_Primary_width,30);
		buttonAdd.setFont(Theme.Font_Button);
		buttonAdd.setBackground(Theme.Background_Button_Primary);
		buttonAdd.setForeground(Theme.Color_Button_Primary);
		buttonAdd.addActionListener(this);
		panel.add(buttonAdd);
		
		header = new JLabel();
		header.setBackground(Theme.Background_Header);
		header.setOpaque(true);
		header.setBounds(0, 0, Theme.GUI_width, 75);
		panel.add(header);
		
		this.add(panel);
	}

	public void actionPerformed(ActionEvent ae) 
	{
		if (ae.getSource().equals(buttonLogout)) 
		{
			this.setVisible(false);
			new LoginActions().setVisible(true);
		}
		else if (ae.getSource().equals(buttonBack)) 
		{
			this.setVisible(false);
			new ViewProductActions(new EmployeeActions(employee.getUserId()), employee).setVisible(true);
		}
		else if (ae.getSource().equals(buttonAdd)) 
		{
			try 
			{
				Product p = new Product();
				p.setProductName(productNameA.getText().trim());
				p.setPrice(Double.parseDouble(productPriceA.getText()));
				p.setQuantity(Integer.parseInt(productQtA.getText()));
				p.createProduct();
				productNameA.setText("");
				productPriceA.setText("");
				productQtA.setText("");
				if (!actions.keywordA.getText().trim().isEmpty())
				{
					actions.table.setModel(Product.searchProduct(actions.keywordA.getText().trim(), actions.byWhatCB.getSelectedItem().toString()));
				}
				else
				{	
					actions.table.setModel(Product.searchProduct("", "By Name"));
				}
			}
			catch (NumberFormatException e) 
			{
				JOptionPane.showMessageDialog(this,"Enter price/quantity correctly!"); 
			}
			catch (IllegalArgumentException e) 
			{
				JOptionPane.showMessageDialog(this,e.getMessage()); 
			}
		}
		else {}
	}
}