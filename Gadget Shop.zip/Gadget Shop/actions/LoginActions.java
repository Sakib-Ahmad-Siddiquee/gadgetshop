package actions;

import java.lang.*;
import javax.swing.*;
import java.awt.*;
import javax.swing.border.*;
import java.awt.event.*;
import attr.*;


public class LoginActions extends JFrame implements ActionListener 
{
	private JPanel panel;
	private JButton buttonLogIn, buttonSignUp, buttonExit;
	private JLabel header, title, usernameLabel, passwordLabel;
	private JTextField usernameA;
	private JPasswordField passwordA;
	
	public LoginActions()
	{
		super("Login");
		
		this.setSize(Theme.GUI_width, Theme.GUI_height);
		this.setResizable(false);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setLocationRelativeTo(null);
		
		panel = new JPanel();
		panel.setLayout(null);
		panel.setBackground(Theme.Background_Panel);
		
		title = new JLabel("Gadget Shop Management System");
		title.setBounds(150, 40, 700, 80);
		title.setOpaque(true);
		title.setBorder(new EmptyBorder(0, 20, 0, 0));
		title.setFont(Theme.Font_Title);
		title.setForeground(Theme.Color_Title);
		panel.add(title);
		
		
		buttonSignUp = new JButton("Sign Up");
		buttonSignUp.setBounds(390, 450, Theme.Button_Primary_width,35);
		buttonSignUp.setFont(Theme.Font_Button);
		buttonSignUp.setBackground(Theme.Background_Button_Primary);
		buttonSignUp.setForeground(Theme.Color_Button_Primary);
		buttonSignUp.addActionListener(this);
		panel.add(buttonSignUp);
		
		
		buttonExit = new JButton("Exit");
		buttonExit.setBounds(Theme.GUI_width-460, 450, Theme.Button_Primary_width, 35);
		buttonExit.setFont(Theme.Font_Button);
		buttonExit.setBackground(Theme.Background_Button_Primary);
		buttonExit.setForeground(Theme.Color_Button_Primary);
		buttonExit.addActionListener(this);
		panel.add(buttonExit);
		
		usernameLabel = new JLabel("User ID: ");
		usernameLabel.setBounds(330, 220, 220, 30);
		usernameLabel.setFont(Theme.Font_Regular);
		panel.add(usernameLabel);
		
		usernameA = new JTextField();
		usernameA.setBounds(440, 220, 220, 30);
		usernameA.setFont(Theme.Font_Input);
		panel.add(usernameA);
		
		passwordLabel = new JLabel("Password: ");
		passwordLabel.setBounds(330, 280, 120, 30);
		passwordLabel.setFont(Theme.Font_Regular);
		panel.add(passwordLabel);
		
		passwordA = new JPasswordField();
		passwordA.setBounds(440, 280, 220, 30);
		passwordA.setFont(Theme.Font_Input);
		panel.add(passwordA);
		
		buttonLogIn = new JButton("Login");
		buttonLogIn.setBounds(440, 345, 150, 40);
		buttonLogIn.setFont(Theme.Font_Button);
		buttonLogIn.setBackground(Theme.Background_Button_Primary);
		buttonLogIn.setForeground(Theme.Color_Button_Primary);
		buttonLogIn.addActionListener(this);
		panel.add(buttonLogIn);
		
		header = new JLabel();
		header.setBackground(Theme.Background_Header);
		header.setOpaque(true);
		header.setBounds(0, 0, Theme.GUI_width, 75);
		panel.add(header);
		
		this.add(panel);
	}
	public void actionPerformed(ActionEvent ae) 
	{
		if (ae.getSource().equals(buttonExit))
		{
			System.exit(0);
		}
		else if (ae.getSource().equals(buttonSignUp)) 
		{
			this.setVisible(false);
			new SignUpActions().setVisible(true);
		}
		else if (ae.getSource().equals(buttonLogIn)) 
		{
			int status = User.checkStatus(usernameA.getText(), passwordA.getText());
			
			if (status == 0) 
			{
				EmployeeActions ea = new EmployeeActions(usernameA.getText());
				ea.setVisible(true);
				this.setVisible(false);
			}
			else if (status == 1) 
			{
				CustomerActions ca = new CustomerActions(usernameA.getText());
				ca.setVisible(true);
				this.setVisible(false);
			}
			else 
			{
				JOptionPane.showMessageDialog(this,"Invalid ID or Password"); 
			}
		}
		else {}
	}
		
	
}
