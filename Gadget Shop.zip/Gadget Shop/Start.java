import java.lang.*;
import actions.*;

public class Start 
{
	public static void main(String args[]) {
		LoginActions lol = new LoginActions();
		lol.setVisible(true);
	}
}