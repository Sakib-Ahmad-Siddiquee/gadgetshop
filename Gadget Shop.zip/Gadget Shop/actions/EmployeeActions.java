package actions;

import java.lang.*;
import javax.swing.*;
import java.awt.*;
import javax.swing.border.*;
import java.awt.event.*;
import attr.*;

public class EmployeeActions extends JFrame implements ActionListener {
	private JPanel panel;
	private Employee employee;
	private JButton buttonLogout, buttonProfile, buttonViewProduct;
	private JButton buttonViewCustomer, buttonViewEmployee;
	private JLabel title, header;
	
	public EmployeeActions(String userId) {
		super("Dashboard - Employee");
		
		this.setSize(Theme.GUI_width, Theme.GUI_height);
		this.setResizable(false);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setLocationRelativeTo(null);
		
		employee = new Employee(userId);
		employee.fetch();
		
		panel = new JPanel();
		panel.setLayout(null);
		panel.setBackground(Theme.Background_Panel);
		
		title = new JLabel("Welcome, "+userId);
		title.setBounds(350, 40, userId.length()*30+220,75);
		title.setOpaque(true);
		title.setBorder(new EmptyBorder(0,20,0,0));
		title.setFont(Theme.Font_Title);
		title.setForeground(Theme.Color_Title);
		panel.add(title);
		
		buttonLogout = new JButton("Logout");
		buttonLogout.setBounds(Theme.GUI_width-350, 160, 200,30);
		buttonLogout.setFont(Theme.Font_Button);
		buttonLogout.setBackground(Color.WHITE);
		buttonLogout.setForeground(Theme.Color_Title);
		buttonLogout.addActionListener(this);
		panel.add(buttonLogout);
		
		buttonProfile = new JButton("My Profile");
		buttonProfile.setBounds(Theme.GUI_width-350, 200, 200,30);
		buttonProfile.setFont(Theme.Font_Button);
		buttonProfile.setBackground(Theme.Background_Button_Primary);
		buttonProfile.setForeground(Theme.Color_Button_Primary);
		buttonProfile.addActionListener(this);
		panel.add(buttonProfile);
		
		buttonViewProduct = new JButton("View Product");
		buttonViewProduct.setBounds(200, 160, 200, 30);
		buttonViewProduct.setFont(Theme.Font_Button);
		buttonViewProduct.setBackground(Theme.Background_Button_Primary);
		buttonViewProduct.setForeground(Theme.Color_Button_Primary);
		buttonViewProduct.addActionListener(this);
		panel.add(buttonViewProduct);
		
		buttonViewCustomer = new JButton("View Customer");
		buttonViewCustomer.setBounds(200, 200, 200, 30);
		buttonViewCustomer.setFont(Theme.Font_Button);
		buttonViewCustomer.setBackground(Theme.Background_Button_Primary);
		buttonViewCustomer.setForeground(Theme.Color_Button_Primary);
		buttonViewCustomer.addActionListener(this);
		panel.add(buttonViewCustomer);
		
		if (employee.getRole().equals("Manager")) 
		{
			buttonViewEmployee = new JButton("View Employee");
			buttonViewEmployee.setBounds(200, 240, 200, 30);
			buttonViewEmployee.setFont(Theme.Font_Button);
			buttonViewEmployee.setBackground(Theme.Background_Button_Primary);
			buttonViewEmployee.setForeground(Theme.Color_Button_Primary);
			buttonViewEmployee.addActionListener(this);
			panel.add(buttonViewEmployee);
		}
		
		header = new JLabel();
		header.setBackground(Theme.Background_Header);
		header.setOpaque(true);
		header.setBounds(0, 0, Theme.GUI_width, 75);
		panel.add(header);
		
		this.add(panel);
	}
	
	public void actionPerformed(ActionEvent ae) 
	{
		if (ae.getSource().equals(buttonProfile)) 
		{
			this.setVisible(false);
			new MyProfileActions(this, employee).setVisible(true);
		}
		else if (ae.getSource().equals(buttonLogout)) 
		{
			this.setVisible(false);
			new LoginActions().setVisible(true);
		}
		else if (ae.getSource().equals(buttonViewProduct)) 
		{
			this.setVisible(false);
			new ViewProductActions(this, employee).setVisible(true);
		}
		else if (ae.getSource().equals(buttonViewCustomer))	
		{
			this.setVisible(false);
			new ViewCustomerActions(this, employee).setVisible(true);
		}
		else if (ae.getSource().equals(buttonViewEmployee)) 
		{
			this.setVisible(false);
			new ViewEmployeeActions(this, employee).setVisible(true);
		}
		else {}
	}
}