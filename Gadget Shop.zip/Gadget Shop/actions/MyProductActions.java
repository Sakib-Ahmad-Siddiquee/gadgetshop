package actions;

import java.lang.*;
import java.util.*;
import javax.swing.*;
import java.awt.*;
import javax.swing.border.*;
import java.awt.event.*;
import javax.swing.table.*;
import attr.*;

public class MyProductActions extends JFrame implements ActionListener {
	private JPanel panel;
	private Customer customer;
	private JFrame actions;
	private JScrollPane frame;
	private JTable table;
	private JButton buttonLogout, buttonBack, buttonCheck;
	private JLabel title, header, keywordLabel, productNameLabel, productQtLabel, productPriceLabel;
	private JTextField keywordA, productNameA, productQtA, productPriceA;
	
	public MyProductActions(JFrame prev, Customer customer) 
	{
		super("Purchase History");
		
		this.setSize(Theme.GUI_width, Theme.GUI_height);
		this.setResizable(false);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setLocationRelativeTo(null);
		this.actions = prev;
		this.customer = customer;
		
		panel = new JPanel();
		panel.setLayout(null);
		panel.setBackground(Theme.Background_Panel);
		
		title = new JLabel("Purchase History");
		title.setBounds(310, 40, 380,75);
		title.setOpaque(true);
		title.setBorder(new EmptyBorder(0,20,0,0));
		title.setFont(Theme.Font_Title);
		title.setForeground(Theme.Color_Title);
		panel.add(title);
		
		buttonLogout = new JButton("Logout");
		buttonLogout.setBounds(Theme.GUI_width-140, 140, Theme.Button_Primary_width,30);
		buttonLogout.setFont(Theme.Font_Button);
		buttonLogout.setBackground(Color.WHITE);
		buttonLogout.setForeground(Theme.Color_Title);
		buttonLogout.addActionListener(this);
		panel.add(buttonLogout);
		
		buttonBack = new JButton("Back");
		buttonBack.setBounds(Theme.GUI_width-140, 180, Theme.Button_Primary_width,30);
		buttonBack.setFont(Theme.Font_Button);
		buttonBack.setBackground(Theme.Background_Button_Primary);
		buttonBack.setForeground(Theme.Color_Button_Primary);
		buttonBack.addActionListener(this);
		panel.add(buttonBack);
		
		table = new JTable();
		table.setModel(customer.myProduct());
		frame = new JScrollPane(table);
		frame.setBounds(40,140,600,300);
		panel.add(frame);
		
		header = new JLabel();
		header.setBackground(Theme.Background_Header);
		header.setOpaque(true);
		header.setBounds(0, 0, Theme.GUI_width, 75);
		panel.add(header);
		
		this.add(panel);
	}
	
	public void actionPerformed(ActionEvent ae) 
	{
		if (ae.getSource().equals(buttonLogout)) 
		{
			this.setVisible(false);
			new LoginActions().setVisible(true);
		}
		else if (ae.getSource().equals(buttonBack)) 
		{
			this.setVisible(false);
			actions.setVisible(true);
		}
		else {}
	}
	
	private void jTable_ClickMouseClicked(MouseEvent evt) //may be it will be changed in future;
	{                                          
       
    }
}