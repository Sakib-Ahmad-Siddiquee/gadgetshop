package actions;

import java.lang.*;
import java.util.*;
import javax.swing.*;
import java.awt.*;
import javax.swing.border.*;
import java.awt.event.*;
import attr.*;

public class AddEmployeeActions extends JFrame implements ActionListener {
	private JPanel panel;
	private ViewEmployeeActions actions;
	private JButton buttonLogout, buttonBack, buttonAdd, buttonEdit, buttonDelete, buttonRandom;
	private JLabel title, header, employeeIdLabel, employeeNameLabel, roleLabel, employeePhoneLabel, salaryLabel;
	private JComboBox roleCB;
	private JTextField employeeIdA, employeeNameA, salaryA, employeePhoneA1, employeePhoneA2, passwordA;
	private Random r;
	
	public AddEmployeeActions(ViewEmployeeActions prev, Employee employee) {
		super("Add Employee");
		
		this.setSize(Theme.GUI_width, Theme.GUI_height);
		this.setResizable(false);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setLocationRelativeTo(null);
		this.actions = prev;
		r = new Random();
		
		panel = new JPanel();
		panel.setLayout(null);
		panel.setBackground(Theme.Background_Panel);
		
		title = new JLabel("Add Employee");
		title.setBounds(330, 40, 340,75);
		title.setOpaque(true);
		title.setBorder(new EmptyBorder(0,20,0,0));
		title.setFont(Theme.Font_Title);
		title.setForeground(Theme.Color_Title);
		panel.add(title);
		
		buttonLogout = new JButton("Logout");
		buttonLogout.setBounds(Theme.GUI_width-140, 140, Theme.Button_Primary_width, 30);
		buttonLogout.setFont(Theme.Font_Button);
		buttonLogout.setBackground(Color.WHITE);
		buttonLogout.setForeground(Theme.Color_Title);
		buttonLogout.addActionListener(this);
		panel.add(buttonLogout);
		
		buttonBack = new JButton("Back");
		buttonBack.setBounds(Theme.GUI_width-140, 180, Theme.Button_Primary_width, 30);
		buttonBack.setFont(Theme.Font_Button);
		buttonBack.setBackground(Theme.Background_Button_Primary);
		buttonBack.setForeground(Theme.Color_Button_Primary);
		buttonBack.addActionListener(this);
		panel.add(buttonBack);
		
		employeeIdLabel = new JLabel("Employee ID: ");
		employeeIdLabel.setBounds(60, 140, 140, 30);
		employeeIdLabel.setFont(Theme.Font_Regular);
		panel.add(employeeIdLabel);
		
		employeeIdLabel = new JLabel("Password: ");
		employeeIdLabel.setBounds(60, 190, 140, 30);
		employeeIdLabel.setFont(Theme.Font_Regular);
		panel.add(employeeIdLabel);
		
		employeeNameLabel = new JLabel("Name: ");
		employeeNameLabel.setBounds(60, 240, 140, 30);
		employeeNameLabel.setFont(Theme.Font_Regular);
		panel.add(employeeNameLabel);
		
		employeePhoneLabel = new JLabel("Phone No: ");
		employeePhoneLabel.setBounds(60, 290, 140, 30);
		employeePhoneLabel.setFont(Theme.Font_Regular);
		panel.add(employeePhoneLabel);
		
		roleLabel = new JLabel("Role: ");
		roleLabel.setBounds(60, 340, 340, 30);
		roleLabel.setFont(Theme.Font_Regular);
		panel.add(roleLabel);
		
		salaryLabel = new JLabel("Salary: ");
		salaryLabel.setBounds(60, 390, 140, 30);
		salaryLabel.setFont(Theme.Font_Regular);
		panel.add(salaryLabel);
		
		employeeIdA = new JTextField();
		employeeIdA.setBounds(180, 140, 220, 30);
		employeeIdA.setFont(Theme.Font_Input);
		panel.add(employeeIdA);
		
		passwordA = new JTextField(""+(r.nextInt(89999999)+10000000));
		passwordA.setBounds(180, 190, 220, 30);
		passwordA.setFont(Theme.Font_Input);
		passwordA.setEnabled(false);
		passwordA.setDisabledTextColor(Color.BLACK);
		panel.add(passwordA);
		
		buttonRandom = new JButton("Generate");
		buttonRandom.setBounds(400, 190, 150, 30);
		buttonRandom.setFont(Theme.Font_Button);
		buttonRandom.setBackground(Theme.Background_Button_Primary);
		buttonRandom.setForeground(Theme.Color_Button_Primary);
		buttonRandom.addActionListener(this);
		panel.add(buttonRandom);
		
		employeeNameA = new JTextField();
		employeeNameA.setBounds(180, 240, 220, 30); 
		employeeNameA.setFont(Theme.Font_Input);
		panel.add(employeeNameA);
		
		employeePhoneA1 = new JTextField("+880");
		employeePhoneA1.setBounds(180, 290, 50, 30);
		employeePhoneA1.setEnabled(false);
		employeePhoneA1.setFont(Theme.Font_Input);
		panel.add(employeePhoneA1);
	
		employeePhoneA2= new JTextField();
		employeePhoneA2.setBounds(225, 290, 180, 30);
		employeePhoneA2.setFont(Theme.Font_Input);
		panel.add(employeePhoneA2);
		
		roleCB = new JComboBox(Employee.roles);
		roleCB.setBounds(180, 340, 160, 30);
		roleCB.setFont(Theme.Font_Input);
		panel.add(roleCB);
		
		salaryA = new JTextField();
		salaryA.setBounds(180, 390, 220, 30);
		salaryA.setFont(Theme.Font_Input);
		panel.add(salaryA);
		
		buttonAdd = new JButton("Add");
		buttonAdd.setBounds(60, 440, Theme.Button_Primary_width, 30);
		buttonAdd.setFont(Theme.Font_Button);
		buttonAdd.setBackground(Theme.Background_Button_Primary);
		buttonAdd.setForeground(Theme.Color_Button_Primary);
		buttonAdd.addActionListener(this);
		panel.add(buttonAdd);
		
		header = new JLabel();
		header.setBackground(Theme.Background_Header);
		header.setOpaque(true);
		header.setBounds(0, 0, Theme.GUI_width, 75);
		panel.add(header);
		
		this.add(panel);
	}

	public void actionPerformed(ActionEvent ae) 
	{
		if (ae.getSource().equals(buttonLogout)) 
		{
			this.setVisible(false);
			new LoginActions().setVisible(true);
		}
		else if (ae.getSource().equals(buttonBack)) 
		{
			this.setVisible(false);
			actions.setVisible(true);
		}
		else if (ae.getSource().equals(buttonAdd)) 
		{
			try 
			{
				Employee e = new Employee(employeeIdA.getText().trim());
				e.setPassword(passwordA.getText().trim());
				e.setEmployeeName(employeeNameA.getText().trim());
				e.setPhoneNumber(Integer.parseInt(employeePhoneA2.getText()));
				e.setSalary(Double.parseDouble(salaryA.getText()));
				e.setRole(roleCB.getSelectedItem().toString());
				e.createEmployee();
				employeeIdA.setText("");
				employeeNameA.setText("");
				employeePhoneA2.setText("");
				salaryA.setText("");
				roleCB.setSelectedIndex(0);
				if (!actions.keywordA.getText().trim().isEmpty())
				{
					actions.table.setModel(Employee.searchEmployee(actions.keywordA.getText().trim(), actions.byWhatCB.getSelectedItem().toString()));
				}
				else
				{
					actions.table.setModel(Employee.searchEmployee("", "By Name"));
				}
			}
			catch (NumberFormatException e) 
			{
				JOptionPane.showMessageDialog(this,"Enter phone no correctly!"); 
			}
			catch (IllegalArgumentException e) 
			{
				JOptionPane.showMessageDialog(this,e.getMessage()); 
			}
		}
		else if (ae.getSource().equals(buttonRandom)) 
		{
			passwordA.setText(""+(r.nextInt(89999999)+10000000));
		}
		else {}
	}
}