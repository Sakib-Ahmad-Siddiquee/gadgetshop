package actions;

import java.lang.*;
import javax.swing.*;
import java.awt.*;
import javax.swing.border.*;
import java.awt.event.*;
import java.sql.*;
import attr.*;

public class SignUpActions extends JFrame implements ActionListener {
	private JPanel panel;
	private JButton buttonExit, buttonSubmit, buttonBack;
	private JLabel title, header, usernameLabel, passwordLabel, nameLabel, phoneLabel, addressLabel;
	private JTextField usernameA, nameA, phoneA1, phoneA2, addressA;
	private JPasswordField passwordA;
	
	public SignUpActions() 
	{
		super("Sign Up");
		
		this.setSize(Theme.GUI_width, Theme.GUI_height);
		this.setResizable(false);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setLocationRelativeTo(null);
		
		panel = new JPanel();
		panel.setLayout(null);
		panel.setBackground(Theme.Background_Panel);
		
		title = new JLabel("Sign Up");
		title.setBounds(300, 40, 400,75);
		title.setOpaque(true);
		title.setBorder(new EmptyBorder(0,20,0,0));
		title.setFont(Theme.Font_Title);
		title.setForeground(Theme.Color_Title);
		panel.add(title);
		
		buttonBack = new JButton("Back");
		buttonBack.setBounds(200, 460, Theme.Button_Primary_width, 30);
		buttonBack.setFont(Theme.Font_Button);
		buttonBack.setBackground(Theme.Background_Button_Primary);
		buttonBack.setForeground(Theme.Color_Button_Primary);
		buttonBack.addActionListener(this);
		panel.add(buttonBack);
		
		buttonExit = new JButton("Exit");
		buttonExit.setBounds(Theme.GUI_width-250, 460, Theme.Button_Primary_width, 30);
		buttonExit.setFont(Theme.Font_Button);
		buttonExit.setBackground(Theme.Background_Button_Primary);
		buttonExit.setForeground(Theme.Color_Button_Primary);
		buttonExit.addActionListener(this);
		panel.add(buttonExit);
		
		usernameLabel = new JLabel("User ID: ");
		usernameLabel.setBounds(330, 140, 140, 30);
		usernameLabel.setFont(Theme.Font_Regular);
		panel.add(usernameLabel);
		
		passwordLabel = new JLabel("Password: ");
		passwordLabel.setBounds(330, 190, 140, 30);
		passwordLabel.setFont(Theme.Font_Regular);
		panel.add(passwordLabel);
		
		nameLabel = new JLabel("Name: ");
		nameLabel.setBounds(330, 240, 140, 30);
		nameLabel.setFont(Theme.Font_Regular);
		panel.add(nameLabel);
		
		phoneLabel = new JLabel("Phone No: ");
		phoneLabel.setBounds(330, 290, 140, 30);
		phoneLabel.setFont(Theme.Font_Regular);
		panel.add(phoneLabel);
		
		addressLabel = new JLabel("Address: ");
		addressLabel.setBounds(330, 340, 140, 30);
		addressLabel.setFont(Theme.Font_Regular);
		panel.add(addressLabel);
		
		usernameA = new JTextField();
		usernameA.setBounds(440, 140, 220, 30);
		usernameA.setFont(Theme.Font_Input);
		panel.add(usernameA);
		
		passwordA = new JPasswordField();
		passwordA.setBounds(440, 190, 220, 30);
		passwordA.setFont(Theme.Font_Input);
		panel.add(passwordA);
		
		nameA = new JTextField();
		nameA.setBounds(440, 240, 220, 30);
		nameA.setFont(Theme.Font_Input);
		panel.add(nameA);
		
		phoneA1 = new JTextField("+880");
		phoneA1.setBounds(440, 290, 40, 30);
		phoneA1.setForeground(Theme.Color_Button_Primary);
		phoneA1.setEnabled(false);
		phoneA1.setFont(Theme.Font_Input);
		phoneA1.setDisabledTextColor(Color.BLACK);
		panel.add(phoneA1);
		
		phoneA2 = new JTextField();
		phoneA2.setBounds(480, 290, 180, 30);
		phoneA2.setFont(Theme.Font_Input);
		panel.add(phoneA2);
		
		addressA = new JTextField();
		addressA.setBounds(440, 340, 220, 30);
		addressA.setFont(Theme.Font_Input);
		panel.add(addressA);
		
		buttonSubmit = new JButton("Submit");
		buttonSubmit.setBounds(440, 400, 180, 35);
		buttonSubmit.setFont(Theme.Font_Button);
		buttonSubmit.setBackground(Theme.Background_Button_Primary);
		buttonSubmit.setForeground(Theme.Color_Button_Primary);
		buttonSubmit.addActionListener(this);
		panel.add(buttonSubmit);
		
		header = new JLabel();
		header.setBackground(Theme.Background_Header);
		header.setOpaque(true);
		header.setBounds(0, 0, Theme.GUI_width, 75);
		panel.add(header);
		
		this.add(panel);
	}
	
	public void actionPerformed(ActionEvent ae) 
	{
		if (ae.getSource().equals(buttonExit))
		{
			System.exit(0);
		}
		else if (ae.getSource().equals(buttonBack)) 
		{
			this.setVisible(false);
			new LoginActions().setVisible(true);
		}
		else if (ae.getSource().equals(buttonSubmit)) 
		{
			try 
			{
				Customer c = new Customer(usernameA.getText().trim());
				c.setPassword(passwordA.getText());
				c.setCustomerName(nameA.getText());
				c.setPhoneNumber(Integer.parseInt(phoneA2.getText()));
				c.setAddress(addressA.getText());
				c.createCustomer(this);
			}
			catch (NumberFormatException e) 
			{
				JOptionPane.showMessageDialog(this,"Enter the phone number correctly!"); 
			}
			catch (IllegalArgumentException e) 
			{
				JOptionPane.showMessageDialog(this, e.getMessage()); 
			}
		}
		else {}
	}
}