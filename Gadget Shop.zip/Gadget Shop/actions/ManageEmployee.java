package actions;

import java.lang.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import attr.*;

public class ManageEmployee extends JFrame implements ActionListener {
	private JPanel panel;
	private ViewEmployeeActions prev;
	private Employee employee;
	private JButton buttonBack, buttonEdit, buttonDelete;
	private JLabel title, header, userIdLabel, employeeNameLabel, phoneNumberLabel, roleLabel, salaryLabel;
	private JTextField userIdA, employeeNameA, phoneNumberA, phoneCodeA, salaryA;
	private JComboBox roleCB;
	
	public ManageEmployee(String eid, ViewEmployeeActions prev) {
		super("Manage Employee");
		
		this.setSize(500,400);
		this.setResizable(false);
		this.setLocationRelativeTo(null);
		this.prev = prev;
		
		employee = new Employee(eid);
		employee.fetch();
		
		panel = new JPanel();
		panel.setLayout(null);
		panel.setBackground(Theme.Background_Panel);
		
		userIdLabel = new JLabel("Employee ID: "+employee.getUserId());
		userIdLabel.setBounds(60, 20, 200, 30);
		userIdLabel.setFont(Theme.Font_Input);
		panel.add(userIdLabel);
		
		employeeNameLabel = new JLabel("Name: ");
		employeeNameLabel.setBounds(60, 60, 140, 30);
		employeeNameLabel.setFont(Theme.Font_Input);
		panel.add(employeeNameLabel);
		
		phoneNumberLabel = new JLabel("Phone: ");
		phoneNumberLabel.setBounds(60, 100, 140, 30);
		phoneNumberLabel.setFont(Theme.Font_Input);
		panel.add(phoneNumberLabel);
		
		roleLabel = new JLabel("Role: ");
		roleLabel.setBounds(60, 140, 140, 30);
		roleLabel.setFont(Theme.Font_Input);
		panel.add(roleLabel);
		
		salaryLabel = new JLabel("Salary: ");
		salaryLabel.setBounds(60, 180, 140, 30);
		salaryLabel.setFont(Theme.Font_Input);
		panel.add(salaryLabel);
		
		employeeNameA = new JTextField(employee.getEmployeeName());
		employeeNameA.setBounds(160, 60, 220, 30);
		employeeNameA.setFont(Theme.Font_Input);
		panel.add(employeeNameA);
		
		phoneCodeA = new JTextField("+880");
		phoneCodeA.setEnabled(false);
		phoneCodeA.setBounds(160, 100, 40, 30);
		phoneCodeA.setFont(Theme.Font_Input);
		panel.add(phoneCodeA);
		

		phoneNumberA = new JTextField(employee.getPhoneNumber().substring(4)+"");
		phoneNumberA.setBounds(200, 100, 180, 30);
		phoneNumberA.setFont(Theme.Font_Input);
		panel.add(phoneNumberA);
		
		roleCB = new JComboBox(Employee.roles);
		roleCB.setBounds(160, 140, 160, 30);
		roleCB.setSelectedIndex(employee.getRole().equals("Manager") ? 1 : 0);
		roleCB.setFont(Theme.Font_Input);
		panel.add(roleCB);
		
		salaryA = new JTextField(employee.getSalary()+"");
		salaryA.setBounds(160, 180, 220, 30);
		salaryA.setFont(Theme.Font_Input);
		panel.add(salaryA);
		
		buttonEdit = new JButton("Save");
		buttonEdit.setBounds(60, 220, Theme.Button_Primary_width,30);
		buttonEdit.setFont(Theme.Font_Button);
		buttonEdit.setBackground(Theme.Background_Button_Primary);
		buttonEdit.setForeground(Theme.Color_Button_Primary);
		buttonEdit.addActionListener(this);
		panel.add(buttonEdit);
		
		buttonDelete = new JButton("Delete");
		buttonDelete.setBounds(180, 220, Theme.Button_Primary_width,30);
		buttonDelete.setFont(Theme.Font_Button);
		buttonDelete.setBackground(Theme.Background_Button_Primary);
		buttonDelete.setForeground(Theme.Color_Button_Primary);
		buttonDelete.addActionListener(this);
		panel.add(buttonDelete);
		
		this.add(panel);
	}
	
	public void actionPerformed(ActionEvent ae) 
	{
		if (ae.getSource().equals(buttonEdit)) 
		{
			try 
			{
				employee.updateEmployee(employeeNameA.getText(),Integer.parseInt(phoneNumberA.getText()),roleCB.getSelectedItem().toString(), Double.parseDouble(salaryA.getText()));
				if (!prev.keywordA.getText().trim().isEmpty())
				{
					prev.table.setModel(Employee.searchEmployee(prev.keywordA.getText().trim(), prev.byWhatCB.getSelectedItem().toString()));
				}
				else
				{
					prev.table.setModel(Employee.searchEmployee("", "By Name"));
				}
				this.setVisible(false);
			}
			catch (NumberFormatException e) {
				JOptionPane.showMessageDialog(this,"Invalid Input!"); 
			}
		}
		else if (ae.getSource().equals(buttonDelete)) 
		{
			employee.deleteEmployee();
			if (!prev.keywordA.getText().trim().isEmpty())
			{
				prev.table.setModel(Employee.searchEmployee(prev.keywordA.getText().trim(), prev.byWhatCB.getSelectedItem().toString()));
			}
			else
			{
				prev.table.setModel(Employee.searchEmployee("", "By Name"));
			}
			this.setVisible(false);
		}
		else {}
	}
}